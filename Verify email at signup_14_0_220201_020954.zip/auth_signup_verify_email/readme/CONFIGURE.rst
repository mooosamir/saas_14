To configure this module, you need to:

* `Properly configure your outgoing email server(s)
  <https://www.odoo.com/forum/help-1/question/how-to-configure-email-gateway-282#answer_290>`_.
* Go to *Settings > General Settings -> General settings*, search for
  the *Users* section and enable *Free sign up* in *Customer account*.
