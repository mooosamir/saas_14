* Rafael Blasco <rafaelbn@antiun.com>
* Jairo Llopis <yajo.sk8@gmail.com>
* Simone Orsi <simone.orsi@camptocamp.com>
* Alexandre Díaz <alexandre.diaz@tecnativa.com>
* Eugene Molotov <molotov@it-projects.info>
