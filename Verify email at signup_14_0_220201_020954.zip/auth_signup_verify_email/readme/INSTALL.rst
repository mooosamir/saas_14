* Install `email_validator <https://pypi.org/project/email-validator/>`_
  with ``pip install email_validator`` or equivalent.
